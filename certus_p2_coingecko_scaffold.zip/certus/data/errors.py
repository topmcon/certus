class APIKeyMissing(Exception):
    pass
