from __future__ import annotations
import asyncio, time
from typing import Any, Dict, List, Optional
import httpx
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type
from .errors import *
from ..config import SETTINGS

# Local token bucket limiter (per-minute)
class MinuteRateLimiter:
    def __init__(self, rate_per_min: int):
        self.rate = rate_per_min
        self.tokens = rate_per_min
        self.updated = time.monotonic()

    async def acquire(self):
        while self.tokens <= 0:
            now = time.monotonic()
            elapsed = now - self.updated
            refill = int(elapsed / 60.0 * self.rate)
            if refill > 0:
                self.tokens = min(self.rate, self.tokens + refill)
                self.updated = now
            await asyncio.sleep(0.1)
        self.tokens -= 1

class CoinGeckoError(Exception):
    pass

class CoinGeckoClient:
    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None, timeout_s: float = None, rate_limit_per_min: int = None):
        self.base_url = base_url or SETTINGS.base_url
        self.api_key = api_key if api_key is not None else SETTINGS.cg_api_key
        self.timeout_s = timeout_s or SETTINGS.timeout_s
        self._limiter = MinuteRateLimiter(rate_limit_per_min or SETTINGS.rate_limit_per_min)
        self._headers = {}
        # CoinGecko uses header name variants for Demo/Pro
        if self.api_key:
            # Prefer new demo header; Pro uses x-cg-pro-api-key
            self._headers["x-cg-demo-api-key"] = self.api_key
            self._headers["x-cg-pro-api-key"] = self.api_key

    def _client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(base_url=self.base_url, headers=self._headers, timeout=self.timeout_s)

    @retry(wait=wait_exponential(multiplier=1, min=1, max=20), stop=stop_after_attempt(5), retry=retry_if_exception_type((httpx.HTTPError, CoinGeckoError)))
    async def _get(self, path: str, params: Dict[str, Any]) -> Any:
        await self._limiter.acquire()
        async with self._client() as client:
            r = await client.get(path, params=params)
            if r.status_code == 429:
                # back-off and raise to trigger retry
                raise CoinGeckoError("Rate limited (429)")
            r.raise_for_status()
            return r.json()

    async def ping(self) -> Dict[str, Any]:
        return await self._get("/ping", {})

    async def simple_price(self, ids: List[str], vs: List[str]) -> Dict[str, Any]:
        return await self._get("/simple/price", {"ids": ",".join(ids), "vs_currencies": ",".join(vs), "include_market_cap": "true", "include_24hr_vol": "true", "include_24hr_change": "true"})

    async def coins_markets(self, vs_currency: str, ids: Optional[List[str]] = None, per_page: int = 250, page: int = 1) -> List[Dict[str, Any]]:
        params = {"vs_currency": vs_currency, "order": "market_cap_desc", "per_page": per_page, "page": page, "price_change_percentage": "1h,24h,7d"}
        if ids:
            params["ids"] = ",".join(ids)
        return await self._get("/coins/markets", params)

    async def market_chart_range(self, coin_id: str, vs_currency: str, frm_unix: int, to_unix: int) -> Dict[str, Any]:
        return await self._get(f"/coins/{coin_id}/market_chart/range", {"vs_currency": vs_currency, "from": frm_unix, "to": to_unix})

    async def coins_list(self, include_platform: bool = True) -> List[Dict[str, Any]]:
        return await self._get("/coins/list", {"include_platform": str(include_platform).lower()})
