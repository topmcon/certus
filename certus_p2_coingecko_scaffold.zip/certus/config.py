from __future__ import annotations
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    cg_api_key: str = os.getenv("CG_API_KEY", "")
    base_url: str = os.getenv("CG_BASE_URL", "https://api.coingecko.com/api/v3")
    data_dir: str = os.getenv("DATA_DIR", "./data")
    duckdb_path: str = os.getenv("DUCKDB_PATH", "./data/certus.duckdb")
    timeout_s: float = float(os.getenv("HTTP_TIMEOUT_S", "20"))
    max_retries: int = int(os.getenv("HTTP_MAX_RETRIES", "5"))
    rate_limit_per_min: int = int(os.getenv("RATE_LIMIT_PER_MIN", "25"))  # stay under Demo's ~30/min

SETTINGS = Settings()
